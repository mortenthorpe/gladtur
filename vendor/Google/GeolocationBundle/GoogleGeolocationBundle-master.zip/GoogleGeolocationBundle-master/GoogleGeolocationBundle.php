<?php

namespace Google\GeolocationBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class GoogleGeolocationBundle extends Bundle
{
}
