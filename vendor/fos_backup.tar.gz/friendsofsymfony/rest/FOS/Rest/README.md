FOSRest
=======

This library provides various tools to rapidly develop RESTful APIs:
http://github.com/FriendsOfSymfony/FOSRest

The main goals for now are to provide ways for decoding request bodies
and request format negotiation (inspired by Apache mod_negotiation)

[![Build Status](https://secure.travis-ci.org/FriendsOfSymfony/FOSRest.png)](http://travis-ci.org/FriendsOfSymfony/FOSRest)
