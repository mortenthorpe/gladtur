<?php

namespace Mapping\Fixture;

use Gedmo\Tree\Entity\MappedSuperclass\AbstractClosure;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity
 */
class ClosureTreeClosure extends AbstractClosure
{}
