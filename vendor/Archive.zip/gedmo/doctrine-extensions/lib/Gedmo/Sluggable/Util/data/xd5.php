<?php
$UTF8_TO_ASCII[0xd5] = array(

);
