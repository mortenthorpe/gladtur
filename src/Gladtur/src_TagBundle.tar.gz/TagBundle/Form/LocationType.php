<?php

namespace Gladtur\TagBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;

class LocationType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('readableName', 'text', array('label'=>'Navn'))
			->add('published', 'checkbox', array('label'=>'Skal vises?'))
            ->add('addressZip', 'text', array('label'=>'Post nr.'))
				->add('addressCountry', 'hidden', array('label'=>'Land', 'data'=>'DK'))
            ->add('addressCity', 'text', array('label'=>'Bynavn'))
				->add('addressStreet','text', array('label'=>'Gade/vej navn og nr.'))
		->add('addressExtd', 'textarea', array('label'=>'Adresse fortsat...'))
            ->add('phone', 'text', array('label'=>'Telefon nr.'))
				->add('mail', 'email', array('label'=>'E-mail'))
            ->add('homepage', 'url', array('label'=>'Hjemmeside'))
					->add('contactPerson', 'text', array('label'=>'Kontaktperson'))
            ->add('mediapath','file', array('label'=>'Filsti til billeder'))
        ;
    }

    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Gladtur\TagBundle\Entity\Location'
        ));
    }

    public function getName()
    {
        return 'gladtur_tagbundle_locationtype';
    }
	
	public function __toString(){
		return $this->getName();
	}
}
