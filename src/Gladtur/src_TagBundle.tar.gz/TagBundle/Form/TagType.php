<?php

namespace Gladtur\TagBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;

class TagType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
			->add('readableName', 'text', array('label'=>'Navn'))
				->add('tagCategory','entity',array('class'=>'GladturTagBundle:TagCategory','label'=>'Kategori'))
	        ->add('published', 'checkbox', array('label'=>'Skal vises?'))
	         ->add('textDescription', 'textarea',array('label'=>'Tekst beskrivelse'))
        ;
    }

    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Gladtur\TagBundle\Entity\Tag'
        ));
    }

    public function getName()
    {
        return 'gladtur_tagbundle_tagtype';
    }
	
	public function __toString(){
		return $this->getName();
	}
}
