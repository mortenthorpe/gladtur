<?php

namespace Gladtur\TagBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Gladtur\TagBundle\Entity\UserLocationTagRelevance
 *
 * @ORM\Table(name="user_location_tag_relevance")
 * @ORM\Entity
 */
class UserLocationTagRelevance
{
    /**
     * @var integer $id
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var integer $userId
     *
     * @ORM\Column(name="user_id", type="integer", nullable=true)
     */
    private $userId;

    /**
     * @var integer $locationMapLocationTagId
     *
     * @ORM\Column(name="location_map_location_tag_id", type="integer", nullable=true)
     */
    private $locationMapLocationTagId;

    /**
     * @var boolean $relevant
     *
     * @ORM\Column(name="relevant", type="boolean", nullable=true)
     */
    private $relevant;



    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set userId
     *
     * @param integer $userId
     * @return UserLocationTagRelevance
     */
    public function setUserId($userId)
    {
        $this->userId = $userId;
    
        return $this;
    }

    /**
     * Get userId
     *
     * @return integer 
     */
    public function getUserId()
    {
        return $this->userId;
    }

    /**
     * Set locationMapLocationTagId
     *
     * @param integer $locationMapLocationTagId
     * @return UserLocationTagRelevance
     */
    public function setLocationMapLocationTagId($locationMapLocationTagId)
    {
        $this->locationMapLocationTagId = $locationMapLocationTagId;
    
        return $this;
    }

    /**
     * Get locationMapLocationTagId
     *
     * @return integer 
     */
    public function getLocationMapLocationTagId()
    {
        return $this->locationMapLocationTagId;
    }

    /**
     * Set relevant
     *
     * @param boolean $relevant
     * @return UserLocationTagRelevance
     */
    public function setRelevant($relevant)
    {
        $this->relevant = $relevant;
    
        return $this;
    }

    /**
     * Get relevant
     *
     * @return boolean 
     */
    public function getRelevant()
    {
        return $this->relevant;
    }
}