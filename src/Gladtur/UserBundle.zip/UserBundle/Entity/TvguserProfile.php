<?php
namespace Gladtur\UserBundle\Entity;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="tvguser_profile")
 */
class TvguserProfile
{
    /**
     * @ORM\Id
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    protected $id;
//http://tracehello.wordpress.com/2011/05/08/symfony2-doctrine2-manytomany-association/
// http://docs.doctrine-project.org/projects/doctrine-orm/en/2.0.x/reference/association-mapping.html#many-to-many-unidirectional
/**
 * Owning Side
 *
 * @ORM\ManyToMany(targetEntity="Tag", inversedBy="profiles")
 * @ORM\JoinTable(name="tvguser_profile_tags")
 */
    private $tags;
    
    public function __construct()
    {
        parent::__construct();
        // your own logic
    }

    

}