<?php
namespace Gladtur\UserBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class GladturUserBundle extends Bundle
{
}